import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import math
import numpy as np

class MLP(nn.Module):
    def __init__(self, n_states, n_actions, hidden_dim=128): # 128
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(n_states, hidden_dim)  # input layer
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)  # hidden layer
        self.fc3 = nn.Linear(hidden_dim, n_actions)  # output layer

    def forward(self, x):
        # Activation functions corresponding to each layer
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)


class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity  # Capacity of Replay
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        # The buffer is a queue. When the capacity is exceeded, the transition at the head of the queue is removed.
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)  # random transitions of small batches
        state, action, reward, next_state, done = zip(*batch)  # Unpack into states, actions, etc.
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)


class DQN:
    def __init__(self, n_states, n_actions, cfg):

        self.n_actions = n_actions 
        self.device = cfg.device  # cpu or gpu
        self.gamma = cfg.gamma  # Discount Factor for Rewards
        # e-greedy related parameters
        self.frame_idx = 0  # decay count for epsilon
        self.epsilon = lambda frame_idx: cfg.epsilon_end + \
                                         (cfg.epsilon_start - cfg.epsilon_end) * \
                                         math.exp(-1. * frame_idx / cfg.epsilon_decay)
        self.batch_size = cfg.batch_size
        self.policy_net = MLP(n_states, n_actions, cfg.hidden_dim).to(self.device)
        self.target_net = MLP(n_states, n_actions, cfg.hidden_dim).to(self.device)
        for target_param, param in zip(self.target_net.parameters(),
                                       self.policy_net.parameters()):  # Copy parameters to target network
            target_param.data.copy_(param.data)
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=cfg.lr)  # optimizer
        self.memory = ReplayBuffer(cfg.memory_capacity) 

    def choose_action(self, state):
        ''' 选择动作
        '''
        self.frame_idx += 1
        if random.random() > self.epsilon(self.frame_idx):
            with torch.no_grad():
                state = torch.tensor(state, device=self.device, dtype=torch.float32).unsqueeze(dim=0)
                q_values = self.policy_net(state)
                action = q_values.max(1)[1].item()  # Choose the action with the highest Q value
        else:
            action = random.randrange(self.n_actions)
        return action

    def update(self):
        if len(self.memory) < self.batch_size:  # When the data in memory is less than one batch, the policy net will not be updated
            return
        # Randomly sample a batch of transitions from replay memory

        state_batch, action_batch, reward_batch, next_state_batch, done_batch = self.memory.sample(self.batch_size)
        state_batch = torch.tensor(np.array(state_batch), device=self.device, dtype=torch.float)
        action_batch = torch.tensor(action_batch, device=self.device).unsqueeze(1)
        reward_batch = torch.tensor(reward_batch, device=self.device, dtype=torch.float)
        next_state_batch = torch.tensor(np.array(next_state_batch), device=self.device, dtype=torch.float)
        done_batch = torch.tensor(np.float64(done_batch), device=self.device).to(torch.float32)
        
        # Calculate the Q value corresponding to the current state (s_t, a)
        q_values = self.policy_net(state_batch).gather(dim=1, index=action_batch)  
        
        # Calculate the max of Q value corresponding to the the next state
        next_q_values = self.target_net(next_state_batch).max(1)[0].detach()  
        
        #DDNQ
        #next_q_values = self.policy_net(next_state_batch)
        #next_action_batch = next_q_values.max(1)[1].unsqueeze(1)
        #next_q_values = self.target_net(next_state_batch).gather(dim=1, index=next_action_batch).squeeze(1)
        
        # Calculate the expected Q value. For the terminal state, done_batch[0]=1, 
        # and the corresponding expected_q_value is equal to reward
        expected_q_values = reward_batch + self.gamma * next_q_values * (1 - done_batch)
        loss = nn.MSELoss()(q_values, expected_q_values.unsqueeze(1))  # measures the mean squared error
        
        # Backpropagation
        self.optimizer.zero_grad()
        loss.backward()
        for param in self.policy_net.parameters():  # Gradient Clip
            param.grad.data.clamp_(-1, 1)
        self.optimizer.step()